📄 README.md

# 📚 Book Store Service

A Spring Boot REST API to manage books, authors, customers, and purchases.  
Implements CRUD operations, input validation, exception handling, DTO mapping, testing, logging, and API documentation.

---

## 🚀 Features

- **CRUD Operations** for:
  - Books
  - Authors
  - Customers
  - Purchased Books
- **Entity Relationships**:
  - An author can exist without books or with multiple books.
  - A book can exist without an author, or be attached to an existing or new author.
  - Customers can purchase any available books.
- **DTO ↔ Entity Mapping**
- **Custom Exceptions** with global handler
- **Input Validation** using `jakarta.validation`
- **Swagger UI** for API documentation
- **Logging** with SLF4J
- **Testing**:
  - Unit tests (repository, service, controller)
  - Integration tests (end-to-end flow)
- **Code Quality**:
  - SonarQube analysis
  - JaCoCo coverage reports

---

## 🏗 Tech Stack

- **Java 17**  
- **Spring Boot 3.x** (Web, Data JPA, Validation)  
- **Maven** (Build & Dependency Management)  
- **H2 / MySQL** (Database)  
- **Swagger-UI / OpenAPI** (API documentation)  
- **Mockito & JUnit 5** (Testing)  
- **Lombok** (Boilerplate reduction)  

---

## 📂 Project Structure

src/ ├── main/ │   ├── java/com/hcltech/bookstoreservice │   │   ├── controller/    # REST Controllers │   │   ├── dto/           # Data Transfer Objects │   │   ├── exception/     # Custom exceptions & global handler │   │   ├── mapper/        # DTO ↔ Entity mappers │   │   ├── model/         # JPA entities │   │   ├── repository/    # Spring Data JPA Repositories │   │   ├── service/       # Business logic │   │   └── Application.java │   └── resources/ │       ├── application.properties │       └── data.sql (optional sample data) └── test/ └── java/com/hcltech/bookstoreservice ├── repository/   # Repository tests ├── service/      # Service tests ├── controller/   # Controller tests └── integration/  # Full integration tests

---

## ⚙️ Getting Started

### **1️⃣ Clone the Repository**
```bash
git clone https://github.com/yourusername/bookstore-service.git
cd bookstore-service

2️⃣ Build & Run

Using Maven:

mvn clean install
mvn spring-boot:run

Or run the generated JAR:

java -jar target/bookstore-service-0.0.1-SNAPSHOT.jar


---

🌐 API Documentation

Once the application is running, open:

http://localhost:8080/swagger-ui/index.html


---

🛠 Example API Endpoints

Books

GET /books → Get all books

GET /books/{id} → Get a book by ID

POST /books → Create a new book

PUT /books/{id} → Update book details

DELETE /books/{id} → Delete a book


Authors

GET /authors

POST /authors

PUT /authors/{id}

DELETE /authors/{id}


Customers

GET /customers

POST /customers

PUT /customers/{id}

DELETE /customers/{id}


Purchased Books

GET /purchased-books

POST /purchased-books



---

🧪 Running Tests

Unit Tests

mvn test

Integration Tests

mvn verify

Code Coverage

After running tests:

target/site/jacoco/index.html


---

📌 Assumptions & Notes

Entities have been designed with meaningful relationships as per the requirements.

Input validation is applied where applicable.

Custom exceptions are returned with proper HTTP status codes.

H2 database is used by default; switch to MySQL via application.properties if needed.



---

🏆 Expected Outcomes

Service runs from source code or JAR.

Supports GET, POST, PUT, DELETE requests.

Data is stored and retrievable in the database.

API is documented via Swagger.

Tests verify both unit-level and full integration scenario


