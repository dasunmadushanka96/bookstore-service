package com.hcltech.bookstoreservice.dto;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;


public class AuthorDTO {
    private String authorName;
    private String biography;
    Set<BookDTO> books=new HashSet<>();

    public AuthorDTO() {
    }

    public AuthorDTO(String authorName, LocalDate releaseDate, String biography, Set<BookDTO> books) {
        this.authorName = authorName;
        this.biography = biography;
        this.books = books;
    }



    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String biography) {
        this.biography = biography;
    }

    public Set<BookDTO> getBooks() {
        return books;
    }

    public void setBooks(Set<BookDTO> books) {
        this.books = books;
    }

    @Override
    public String toString() {
        return "AuthorDTO{" +
                "authorName='" + authorName + '\'' +
                ", biography='" + biography + '\'' +
                ", books=" + books +
                '}';
    }
}
