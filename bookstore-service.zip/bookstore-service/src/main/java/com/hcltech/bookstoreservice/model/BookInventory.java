package com.hcltech.bookstoreservice.model;

import jakarta.persistence.*;

@Entity
public class BookInventory {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(nullable = false, length = 50)
    private int quantity;

    @OneToOne
    @JoinColumn(name = "bookId", referencedColumnName = "id", unique = true)
    private Book book;

    public BookInventory() {
    }

    public BookInventory(int id, int quantity, Book book) {
        this.id = id;
        this.quantity = quantity;
        this.book = book;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    @Override
    public String toString() {
        return "BookInventory{" +
                "id=" + getId() +
                ", bookId=" + getBook() +
                ", quantity=" + getQuantity() +
                '}';
    }
}
