package com.hcltech.bookstoreservice.dto;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class BookDTO {

    private Long id;
    private String title;
    private String isbn;
    private double price;
    private LocalDate publicationDate;
    private Set<AuthorDTO> authors=new HashSet<>();

    public BookDTO() {
    }

    public BookDTO(Long id, String title, String isbn, double price, LocalDate publicationDate, Set<AuthorDTO> authors) {
        this.id = id;
        this.title = title;
        this.isbn = isbn;
        this.price = price;
        this.publicationDate = publicationDate;
        this.authors = authors;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(LocalDate publicationDate) {
        this.publicationDate = publicationDate;
    }

    public Set<AuthorDTO> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<AuthorDTO> authors) {
        this.authors = authors;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "BookDTO{" +
                "id=" + getId() +
                ", title='" + getTitle() + '\'' +
                ", isbn=" + getIsbn() +
                ", price=" + getPrice() +
                ", publicationDate=" + getPublicationDate() +
                ", authors=" + getAuthors() +
                '}';
    }
}
