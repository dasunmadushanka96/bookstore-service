package com.hcltech.bookstoreservice.controller;

import com.hcltech.bookstoreservice.dto.OrderBookDTO;
import com.hcltech.bookstoreservice.dto.OrderDTO;
import com.hcltech.bookstoreservice.dto.PurchasedBookDTO;
import com.hcltech.bookstoreservice.service.PurchasedBookService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookstore-service/v1/purchase")
public class PurchaseBookController {

    private PurchasedBookService purchasedBookService;

    public PurchaseBookController(PurchasedBookService purchasedBookService) {
        this.purchasedBookService = purchasedBookService;
    }

    @PostMapping
    public OrderDTO create(@Valid @RequestBody OrderDTO orderDTO){
        return purchasedBookService.create(orderDTO);
    }

    @GetMapping
    public List<OrderBookDTO> get(){
        return purchasedBookService.getAll();
    }

}
