package com.hcltech.bookstoreservice.mapper;

import com.hcltech.bookstoreservice.dto.PurchasedBookDTO;
import com.hcltech.bookstoreservice.model.PurchasedBook;
import com.hcltech.bookstoreservice.model.PurchasedBookPK;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PurchasedBookMapper {

//    private int bookId;
//    private int quantity;
//    private double unitPrice;
//
//    private PurchasedBookPK purchasedBookPK;
//    private int quantity;
//    private double unitPrice;
//
//
//    @Mapping(target = "bookId", source = )
//    PurchasedBookDTO toEntity(PurchasedBook purchasedBook);
//
//    PurchasedBook toDto(PurchasedBookDTO purchasedBookDTO);

}
