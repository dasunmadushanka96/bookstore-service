package com.hcltech.bookstoreservice.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class BookInventoryDTO {

    private int id;
    @NotNull(message = "BookId is required")
    private Long bookId;
    @Min(value = 1, message = "Value must be positive")
    private int quantity;

    public BookInventoryDTO() {
    }

    public BookInventoryDTO(int id, Long bookId, int quantity) {
        this.id = id;
        this.bookId = bookId;
        this.quantity = quantity;
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "BookInventoryDTO{" +
                "id=" + getId() +
                ", bookId=" + getBookId() +
                ", quantity=" + getQuantity() +
                '}';
    }
}
